const PORT = 8000
const axios = require('axios') //Promise based http client for the browser and node.js
const cheerio = require('cheerio') //implementation of jquery and parses data
const express = require('express') //web framework for node js
const cors = require('cors') // middleware for node.js and express


const app = express() //app is our variable used to call express
//below are uses listed with the express npm

app.use(cors())
//cors is used with express as middleware for node.js

//app.METHOD(PATH, HANDLER)

/**
app.listen() // tells express which port to monitor

app.get() //get data

app.post() //add data

app.put() //edit

app.delete() //delete data
*/

app.listen(PORT, () => console.log(`server running on PORT ${PORT}`))
//this function will log the port number to the console


const url = 'https://www.theguardian.com/us'//url that will be passed through axios
axios(url)
    .then(response => {
        const html = response.data  //this is our data that we will scrape
        //console.log(html) //lets log this data to the console for now as a test
        //when you save the code nodemon will automatically run the file in the console
        const $ = cheerio.load(html) //load data into cheerio
        // using $ as the variable name is common practice with cheerio
        const articles = [] //Our articles will go into this array

        //this will search the html for this class (don't forget the period)
        $('.fc-item__title', html).each(function () { //this is an each function
            const title = $(this).text()//Grabs the text of the title
            const url = $(this).find('a').attr('href') //Searches a tags for the URL
            articles.push({ //this builds each item in the array
                title,//We print the title followed by the URL
                url
            })
        })
        console.log(articles)// We print our array to the console
    }).catch(err => console.log (err)) //catches errors in cosole log

